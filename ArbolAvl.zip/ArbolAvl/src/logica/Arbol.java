package logica;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luis Andres Agudelo Padilla - 0221520006
 */
public class Arbol {
    private NodoArbol raiz;
    
    
   public Arbol(){
       
   } 

    public NodoArbol getRaiz() {
        return raiz;
    }

    public void setRaiz(NodoArbol raiz) {
        this.raiz = raiz;
    }
   
   
public NodoArbol buscar(int dato,NodoArbol nodo){
    if(raiz == null){
        System.err.println("Arbol vacio");
        return null;
    }else if(nodo.getDato()==dato){
        System.out.println("Dato encontrado");
        return nodo;
    }
    else if(nodo.getDato()<dato){
        return buscar(dato,nodo.getHijoDerecho());
    }
    else if(nodo.getDato()>dato){
        return buscar(dato,nodo.getHijoIzquierdo());   
    }
    System.err.println("Dato no encontrado");
    return null;
 }

public int calculaFE(NodoArbol nodo){
    if(nodo == null){
        return -1;
    }else{
        return nodo.getFe();
    }
}

public int calcularAltura(NodoArbol nodo){
        if (nodo == null) 
            return 0;
        
        if(calcularAltura(nodo.getHijoDerecho()) >= calcularAltura(nodo.getHijoIzquierdo()))
            return calcularAltura(nodo.getHijoDerecho()) +1;
        else
            return calcularAltura(nodo.getHijoIzquierdo()) + 1;
    }

public NodoArbol rotaI(NodoArbol nodo){
    NodoArbol aux  = nodo.getHijoIzquierdo();
    nodo.setHijoIzquierdo(aux.getHijoDerecho());
    aux.setHijoDerecho(nodo);
    nodo.setFe(Math.max(calculaFE(nodo.getHijoIzquierdo()), calculaFE(nodo.getHijoDerecho()))+1);
    aux.setFe(Math.max(calculaFE(aux.getHijoIzquierdo()),calculaFE(nodo.getHijoDerecho()))+1);
    return aux;
}

public NodoArbol rotaD(NodoArbol nodo){
    NodoArbol aux  = nodo.getHijoDerecho();
    nodo.setHijoDerecho(aux.getHijoIzquierdo());
    aux.setHijoIzquierdo(nodo);
    nodo.setFe(Math.max(calculaFE(nodo.getHijoIzquierdo()), calculaFE(nodo.getHijoDerecho()))+1);
    aux.setFe(Math.max(calculaFE(aux.getHijoIzquierdo()),calculaFE(nodo.getHijoDerecho()))+1);
    return aux;
}
    
public NodoArbol rotaII(NodoArbol nodo){
    NodoArbol aux;
    nodo.setHijoIzquierdo(rotaD(nodo.getHijoIzquierdo()));
    aux = rotaI(nodo);
    return aux;
}

public NodoArbol rotaDD(NodoArbol nodo){ 
    NodoArbol aux;
    nodo.setHijoDerecho(rotaI(nodo.getHijoDerecho()));
    aux = rotaD(nodo);
    return aux;
}
    
public NodoArbol insertarArbol(NodoArbol nuevo, NodoArbol arbol){
    NodoArbol np = arbol;
    if(nuevo.getDato()<arbol.getDato()){
        if(arbol.getHijoIzquierdo()==null){
            arbol.setHijoIzquierdo(nuevo);
         }else{
            arbol.setHijoIzquierdo(insertarArbol(nuevo,arbol.getHijoIzquierdo()));
            if(calculaFE(arbol.getHijoIzquierdo())-calculaFE(arbol.getHijoDerecho())==2){
                if(nuevo.getDato()<arbol.getHijoIzquierdo().getDato()){
                    np = rotaI(arbol);
                }else{
                    np = rotaII(arbol);
                }
            }
        }
    }else if(nuevo.getDato()>arbol.getDato()){
            if(arbol.getHijoDerecho()==null){
                arbol.setHijoDerecho(nuevo);
            }else{
                arbol.setHijoDerecho(insertarArbol(nuevo,arbol.getHijoDerecho())); 
                if(calculaFE(arbol.getHijoDerecho())-calculaFE(arbol.getHijoIzquierdo())==2){
                  if(nuevo.getDato()>arbol.getHijoDerecho().getDato()){
                      np =  rotaD(arbol);
                  }else{
                      np = rotaDD(arbol);
                  }
                }
            }
    }else{
        System.out.println("Todo bien");
    }
    if(arbol.getHijoIzquierdo()==null && arbol.getHijoDerecho()!=null){
        arbol.setFe(arbol.getHijoDerecho().getFe()+1);
    }else if(arbol.getHijoDerecho()==null && arbol.getHijoIzquierdo()!=null){
        arbol.setFe(arbol.getHijoIzquierdo().getFe()+1);
    }else{
        arbol.setFe(Math.max(calculaFE(arbol.getHijoIzquierdo()),calculaFE(arbol.getHijoDerecho()))+1);
    }
    return np;
                    
  }

public boolean insertar(int dato){
    NodoArbol nuevo = new NodoArbol();
    if(raiz == null){
        raiz = nuevo;
    }else{
        raiz = insertarArbol(nuevo, raiz);
    }
    return true;
}
    
public void inOrden (NodoArbol nodo){
    if(nodo!=null){
        inOrden(nodo.getHijoIzquierdo());
        System.out.println(nodo.getDato()+"--");
        inOrden(nodo.getHijoDerecho());
    }
} 

public void preOrden(NodoArbol nodo){
    if(nodo!=null){
        System.out.println(nodo.getDato()+"--");
        preOrden(nodo.getHijoIzquierdo());
        preOrden(nodo.getHijoDerecho());
    }
}
    
    
    /*public void insertar(int dato){
     NodoArbol nuevo = new NodoArbol(dato, null, null);
     if(raiz==null)                
         raiz = nuevo;
      else                          
         {
         NodoArbol auxiliar = raiz;
         while(true){
            if(nuevo.getDato() < auxiliar.getDato())  
               auxiliar = auxiliar.getHijoIzquierdo();     
            else if(nuevo.getDato() > auxiliar.getDato()){
                auxiliar = auxiliar.getHijoDerecho();   
            }
            else if(auxiliar == null){
                auxiliar = nuevo;
                return;
            }
         } 
       }  
    }
    
    public NodoArbol insertar2(NodoArbol nodo, int dato){
        if(raiz ==null){
           NodoArbol nuevo= new NodoArbol(dato,null,null); 
           raiz = nuevo; 
           return nuevo;
        }
        else if(nodo==null){
            NodoArbol nuevo= new NodoArbol(dato,null,null); 
            nodo = nuevo;
        }
        else if(nodo.getDato()<dato){
               nodo.setHijoDerecho(insertar2(nodo.getHijoDerecho(),dato));       
        }
        else if(nodo.getDato()>dato){
           nodo.setHijoIzquierdo(insertar2(nodo.getHijoIzquierdo(),dato));       
        }
        return nodo;
    }
    
    public boolean eliminar(int dato){         // Función que elimina el primer Nodo de la cola.
        NodoArbol actual = raiz;
        NodoArbol padre = raiz;
        boolean esIzquierdo=true;
        while(actual.getDato()!=dato){
            padre = actual;
            if(dato<actual.getDato()){
                actual = actual.getHijoIzquierdo();
                if(actual != null){
                    if(actual.getDato()==dato){
                        esIzquierdo = true;
                        break;
                    }
                }else{
                    return false;
                }
            }else{
                actual = actual.getHijoDerecho();
                if(actual != null){ 
                    if(actual.getDato()==dato){
                        esIzquierdo = false;
                        break;
                    }
                }else{
                    return false;
                }
            }
        }
        if(actual.getHijoDerecho()== null && actual.getHijoIzquierdo()== null ){
            actual = null;
            return true;
        }
        else if(actual.getHijoDerecho()==null && actual.getHijoIzquierdo()!=null){
            if(esIzquierdo){
                padre.setHijoDerecho(actual.getHijoIzquierdo());
                actual =null;
                return true;
            }else{
                 padre.setHijoDerecho(actual.getHijoDerecho());
                 actual =null;
                return true;
            }
        }
        else if(actual.getHijoDerecho()!=null && actual.getHijoIzquierdo()==null){
            if(esIzquierdo){
                padre.setHijoIzquierdo(actual.getHijoIzquierdo());
                actual =null;
                return true;
            }else{
                 padre.setHijoDerecho(actual.getHijoDerecho());
                 actual =null;
                return true;
            }
        }
        else{
            if(esIzquierdo){
                padre.setHijoIzquierdo(actual.getHijoDerecho());
                padre.getHijoIzquierdo().setHijoIzquierdo(actual.getHijoIzquierdo());
                actual =null;
                return true;
            }else{
                 padre.setHijoDerecho(actual.getHijoDerecho());
                 padre.getHijoDerecho().setHijoIzquierdo(actual.getHijoIzquierdo());
                 actual =null;
                return true;
            }
        }   
    }
    
    public void recorridoAnchura(){ 
        ColaArbol cola;
        Cola colaAux; 
        NodoArbol aux; 
        if (raiz != null) {
            cola = new ColaArbol(); 
            colaAux=new Cola(); 
            cola.insertar(raiz); 
            while (!cola.estaVacia()){   
                aux = cola.getInicio().getNodoArbol(); 
                cola.eliminar();
                colaAux.insertar(aux.getDato()); //EL ELEMENTO EXTRAIDO DE LA COLA PRINCIPAL ES ASIGNADO 
                //A AUX Y A SU VEZ INSERTADO EN LA COLA AUXILIAR
                if (aux.getHijoIzquierdo() != null) //SI EL HIJO IZQUIERDO DEL NODO ACTUAL EXISTE
                {
                cola.insertar(aux.getHijoIzquierdo()); //SE INSERTA ESE HIJO COMO ELEMENTO SIGUIENTE EN LA COLA
                }
                if (aux.getHijoDerecho()!= null) //SI EL HIJO DERECHO DEL NODO ACTUAL EXISTE
                {
                cola.insertar(aux.getHijoDerecho()); //SE INSERTA ESE HIJO COMO ELEMENTO SIGUIENTE EN LA COLA
                }
                aux=null;
            }               //colaAux.print(); //POR ÚLTIMO SE IMPRIME LA COLA AUXILIAR    
        }
    }
    
    public void recorridoAltura(NodoArbol nodo){
        if(nodo==null){
            return;
        }
        System.out.println(nodo.getDato());
        recorridoAltura(nodo.getHijoIzquierdo());
        recorridoAltura(nodo.getHijoDerecho());
    }*/
}
    
    

