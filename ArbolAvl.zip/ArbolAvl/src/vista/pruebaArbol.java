/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import javax.swing.JOptionPane;
import logica.*;
/**
 *
 * @author SIS
 */
public class pruebaArbol {
    public static void main(String a[]){
        Arbol arbol = new Arbol();
        int opcion = 0, dato = 0, seguir = 0;
        Exception e=null;
           while(opcion != 7 ){ 
                do{   
                    e=null;
                    try{
                         opcion = Integer.parseInt(JOptionPane.showInputDialog(null,"1. Ingresar Nodo\n2. Mostrar altura\n3. Mostrar Arbol por Profundidad\n4. Salir"));
                     }catch(Exception ex){
                         e = ex;
                         JOptionPane.showMessageDialog(null,"Opcion no valida");
                     }
               }while(e!=null);
                do{
                    e=null;
                    if(opcion<=6&& opcion != 3  && opcion != 5 && opcion != 4){
                        try{
                            dato = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese dato de nodo: "));

                        }catch(NumberFormatException ex){
                                e=ex;
                             JOptionPane.showMessageDialog(null,"Dato no valida");
                        }
                    }
                }while(e!=null);
                
                switch(opcion){
                    case 1:
                        if(arbol.insertar(dato))
                             JOptionPane.showMessageDialog(null,"Nodo Agregado");
                        break;
                    case 2:
                            JOptionPane.showMessageDialog(null,"Altura del Arbol: "+arbol.calcularAltura(arbol.getRaiz()));
                        break;
                    case 3:
                        arbol.preOrden(arbol.getRaiz());
                        break;
                    case 4:
                        return;
                    default:
                        JOptionPane.showMessageDialog(null,"Opcion incorrecta");
                }
           }  
    }
}
