/************************************************* ***********************
* Palabra de honor:
* - No he discutido ni mostrado el código de mi programa con alguien que no sea mi
*compañero, Profesor o con el monitor asignado a este curso.
*
* - No he utilizado código obtenido de otro u otros estudiantes,
* O cualquier otra fuente no autorizada, ya sea modificado o sin modificar.
*
* - Si cualquier código o documentación utilizada en mi programa
* Fue obtenido de otra fuente, tal como un libro de texto o curso
* Notas, debe ser claramente señalado con una cita apropiada en
* Los comentarios de mi programa.
*
* Agudelo Luis - 0221520006
* Perez Camilo - 02215200
*
************************************************** ********************* */
package logica;

/**Declaracion de la clase Agenda
 * @author Agudelo Luis
 * @author Perez Camilo
 */
public class Agenda {
    /**Atributo que contiene el nombre del propietario de la agenda     */  
    private  String propietario;
    /**Atributo(Vector) que contiene la lista de contactos de la agenda     */  
    private Contacto contactos[] = new Contacto[100];
  
   /**Creación del Constructor
    *Inicializa todos los contactos de la agenda en null
     */ 
    public Agenda() {
        for(int i=0;i<99;i++){
            contactos[i] = null;
        }
    }
    
     /**Analizador del atributo contactos
     * 
     * @return contactos
     */
    public Contacto[] getContactos() {
        return contactos;
    }
    
     /**Analizador del atributo propietario
     * 
     * @return propietario
     */
    public String getPropietario() {
        return propietario;
    }
    
    /**Modificador del atributo propietario
     * @param propietario
     */
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    /**Modificador del atributo contactos
     * @param contactos
     */
    public void setContactos(Contacto[] contactos) {
        this.contactos = contactos;
    }
    
     /**Metodo que agrega contactos 
     * @param c representa un objeto de tipo Contacto
     * @return int, si es 4 significa que la agenda está llena y no agrega el contacto; si es 0 significa que se agregó el contacto
     */
   public int añadirContacto(Contacto c){ //returna 1 cuando el telefono es igual no agraga contacto -- returna 2 cuando el correo es igual no agrega contacto returna 12 cuando ambos son iguales -- returna 3 cuando la lista está llena y 0 cuando se guarda el contacto-- return 4 cuanto la agenda está llena;
       //acomodaLista();
       int cantidad = cantidadContactos();
       if(cantidad == 99)
           return 4;
       else{
           
           if(cantidad==0){
             contactos[0]=c;
             return 0;         
           }else{
               
              /*Contacto vector[];
              vector = buscarContacto(c);
              //System.out.println("igual a vector a buscarContacto");
                int band = 0;
                /*if(vector != null){
                    for(int i=0;i<vector.length;i++){
                       if(vector[i].getTelefono() == c.getTelefono() && vector[i].getCorreo()== c.getCorreo())
                           return 12;
                       else{
                           if(vector[i].getTelefono() == c.getTelefono())
                               return 1;
                           else{
                               if(vector[i].getCorreo() == c.getCorreo())
                                    return 2;
                           }
                       }
                    }
                }else{*/
                    for(int i=0;i<100;i++){
                        if(null != contactos[i]){
                        } else {
                            contactos[i]=c;
                            return 0;
                   } 
                     }
                    
                
           }
       }
       return 0;
    }
   
       
    /**Metodo que agrega contactos 
     * @param c representa un objeto de tipo Contacto
     * return un vector de tipo Contacto, con lo(s) contacto(s) encontrado(s).
     */
    public Contacto[] buscarContacto(Contacto c){
       
        int tamaño = 0;
        for(int i=0;i<100;i++){
            if(contactos[i]==null){
                break;
            }
            else{
                if(c.getNombre().equals(contactos[i].getNombre()))
                    tamaño++;
            }
        }
        
       int j=0;
       Contacto vector[] = new Contacto[tamaño];
      
       for(int i=0; i<tamaño;i++){
           vector[i] = null;
       }
       for(int i=0;i<100;i++){
            if(contactos[i] == null)
                break;
            else{
                if(contactos[i].getNombre().equals(c.getNombre())){
                    vector[j] = contactos[i];
                    j++;    
                }
            }
       }
      
        return vector;        
    }
    
    /**Metodo que cuenta los contactos
     * return un int con la cantidad de contactos diferentes a null en la agenda
     */
    public int cantidadContactos(){
        //acomodaLista();
        int cont = 0;
        for(int i=0;i<100;i++){
            if(contactos[i]!=null)
                cont++;
        }
        return cont;
    }
    
    /**Metodo que modifica o edita contactos
     * @param c representa el contacto editado
     * @param p la posición del contacto a editar
     * return un boolean que indica que se guardo el contacto editado
     */
    public boolean modificaContacto(Contacto c, int p){
        contactos[p] = c;
        return true;
        
    }
    
    /**Metodo que modifica o edita contactos
     * @param p la posición del contacto a eliminar
     * return un boolean que indica que se eliminó el contacto en la posición p
     */
    public boolean eliminaContacto(int p){
        contactos[p] = null;
        return true;
    }
    
    /**Metodo que muestra los contactos
     * @return un vector con los contactos diferentes a null de la agenda
     */
    public Contacto[] mostrarContactos(){
        int nContactos = cantidadContactos();
        Contacto vector[] = new Contacto [nContactos];
        acomodaLista();
        System.arraycopy(contactos, 0, vector, 0, nContactos);
        return vector;
    }
    
    /**Metodo que agrupa los contactos diferentes a null, en las primeras posiciones del vector Contactos
     */
    public void acomodaLista(){
        int nContactos = cantidadContactos();
        if(nContactos!=0){
            for(int i=0;i<nContactos;i++){
                for(int j=0;j<100;j++){
                    if(contactos[i]==null){
                        if(contactos[j]!=null){
                            contactos[i] = contactos[j];
                            contactos[j] = null;
                            i++;
                        }
                    }else{
                        i++;
                    }
                }
            }
            
        }
    }

    

    

    
    
    
    
}
