/************************************************* ***********************
* Palabra de honor:
* - No he discutido ni mostrado el código de mi programa con alguien que no sea mi
*compañero, Profesor o con el monitor asignado a este curso.
*
* - No he utilizado código obtenido de otro u otros estudiantes,
* O cualquier otra fuente no autorizada, ya sea modificado o sin modificar.
*
* - Si cualquier código o documentación utilizada en mi programa
* Fue obtenido de otra fuente, tal como un libro de texto o curso
* Notas, debe ser claramente señalado con una cita apropiada en
* Los comentarios de mi programa.
*
* Agudelo Luis - 0221520006
* Perez Camilo - 02215200
*
************************************************** ********************* */
package logica;

/**Declaracion de la clase Contacto
 * @author Agudelo Luis
 * @author Perez Camilo
 */
public class Contacto {
    /**Atributo que contiene el nombre del contacto     */   
    private String nombre;
    /**Atributo que contiene el correo del contacto    */   
    private String correo;
    /**Atributo que contiene el numero de telefono del contacto    */  
    private Long telefono;

   /**Creación del Constructor por defecto
     */
    public Contacto(){
        
   
    }
    
    /**Creación del Constructor
     * 
     * @param nombre representa el nombre del contacto
     * @param correo representa el correo del contacto 
     * @param telefono representa el numero de telefono del contacto 
     * 
     */
    
    public Contacto(String nombre, String correo, long telefono) {
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
    }

     /**Analizador del atributo nombre
     * 
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }
    
     /**Modificador del atributo nombre
     * @param nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
     /**Analizador del atributo correo
     * 
     * @return correo
     */
    public String getCorreo() {
        return correo;
    }
    
    /**Modificador del atributo nombre
     * @param correo
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**Analizador del atributo telefono
     * 
     * @return telefono
     */
    public long getTelefono() {
        return telefono;
    }
    
    /**Modificador del atributo nombre
     * @param telefono
     */
    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }
    
    /**Metodo toString
     * @return  el nombre del contacto, correo y número de telefono
     */
    @Override
    public String toString() {
        return "Nombre: "+nombre+"  Telefono: "+telefono+"  Correo: "+correo;
    }

    
    
    
    
    
    
}
