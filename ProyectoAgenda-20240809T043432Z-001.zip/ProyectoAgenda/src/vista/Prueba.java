/************************************************* ***********************
* Palabra de honor:
* - No he discutido ni mostrado el código de mi programa con alguien que no sea mi
*compañero, Profesor o con el monitor asignado a este curso.
*
* - No he utilizado código obtenido de otro u otros estudiantes,
* O cualquier otra fuente no autorizada, ya sea modificado o sin modificar.
*
* - Si cualquier código o documentación utilizada en mi programa
* Fue obtenido de otra fuente, tal como un libro de texto o curso
* Notas, debe ser claramente señalado con una cita apropiada en
* Los comentarios de mi programa.
*
* Agudelo Luis - 0221520006
* Perez Camilo - 02215200
*
************************************************** ********************* */
package vista;
import java.io.IOException;
import logica.*;
import javax.swing.JOptionPane;
import java.lang.NumberFormatException;
import java.util.Arrays;
import java.lang.NumberFormatException;

/**
 *
 * @author Agudelo Luis
 * @author Camilo Perez
 */
public class Prueba {
    public static void main(String[] e){
        String  nombre, telefono, correo,resp;
        JOptionPane o = new JOptionPane(null);
        int seguir = 1, opcion=0;
        Agenda agenda = new Agenda();
        Contacto c = new Contacto();
        Contacto vector[];
        Contacto vector2[];
        
        while(seguir==1){
            agenda.setPropietario(JOptionPane.showInputDialog("PROGRAMA PARA CREAR AGENTA\n\n\tIngrese su nombre de propietario: "));
            if(validaString(agenda.getPropietario())==false){  
            }else{
                break;
            }
        }
        
        while(seguir == 1){    
            while(seguir==1){
                String op;
                op = JOptionPane.showInputDialog("MENU DE AGENDA\n\n\t1. Anadir contacto.\n\t2. Borrar contacto.\n\t3. Buscar contacto \n\t4. Editar contacto\n\t5. Mostrar contactos.\n\t6. Salir");
                if(validaEntero(op)==true){
                    opcion = Integer.parseInt(op);
                    break;
                }
            }
            
            if(seguir == 0)
                break;
            
            if((opcion>1 && opcion<6) && agenda.cantidadContactos()==0){
                c = new Contacto();
                JOptionPane.showMessageDialog(null, "No hay contactos en la agenda, por favor ingrese contactos");
                while (seguir==1){
                       nombre = JOptionPane.showInputDialog("Contacto #"+ (agenda.cantidadContactos()+1)+"\n\n\tNombre: ");
                        if(validaString(nombre)==true){
                            c.setNombre(nombre);
                            break;
                        }  
                    }
                    while (seguir==1){
                        telefono = JOptionPane.showInputDialog("Contacto #"+ (agenda.cantidadContactos()+1)+"\n\n\tTelefono: ");
                        if(validaEntero(telefono)==true){
                            c.setTelefono(Integer.toUnsignedLong(Integer.parseInt(telefono)));
                            break;
                        }  
                    }
                    while (seguir==1){
                       correo = JOptionPane.showInputDialog("Contacto #"+ (agenda.cantidadContactos()+1)+"\n\n\tCorreo: ");
                        if(validaString(correo)==true){
                            c.setCorreo(correo);
                            break;
                        }  
                    }
                   opcion = 0;
                   agenda.añadirContacto(c);   
            }
            
            switch(opcion){
                case 1:
                    c = new Contacto();
                    int respuesta;
                    seguir = 1;
                    while (seguir==1){
                       nombre = JOptionPane.showInputDialog("Contacto #"+(agenda.cantidadContactos()+1)+"\n\n\tNombre: ");
                        if(validaString(nombre)==true){
                            c.setNombre(nombre);
                            break;
                        }  
                    }
                    while (seguir==1){
                        telefono = JOptionPane.showInputDialog("Contacto #"+ (agenda.cantidadContactos()+1)+"\n\n\tTelefono: ");
                        if(validaEntero(telefono)==true){
                            c.setTelefono(Integer.toUnsignedLong(Integer.parseInt(telefono)));
                            break;
                        }  
                    }
                    while (seguir==1){
                       correo = JOptionPane.showInputDialog("Contacto #"+ (agenda.cantidadContactos()+1)+"\n\n\tCorreo: ");
                        if(validaString(correo)==true){
                            c.setCorreo(correo);
                            break;
                        }  
                    }
                    JOptionPane.showMessageDialog(null,"Contacto a  guardar: \n\n"+c);
                    respuesta = agenda.añadirContacto(c);
                    switch(respuesta){
                        case 0: 
                            JOptionPane.showMessageDialog(null,"El conctacto se agregó correctamente");
                            break;
                        case 4:
                             JOptionPane.showMessageDialog(null,"La agenda está llena, por favor elimine un contacto");
                            break;  
                    }
                    break;
                
                case 2:
                    c = new Contacto();
                    int tamaño=1;
                    nombre = null;
                     resp = null; ;
                    while (seguir==1){
                       nombre = JOptionPane.showInputDialog("Digite el nombre del contacto a borrar: ");
                       if(validaString(nombre)==true)
                           break;
                    }
                    c.setNombre(nombre);
                    vector = agenda.buscarContacto(c).clone();
                    if(vector.length==0)
                         JOptionPane.showMessageDialog(null,"El Contacto no existe en la lista, intente nuevamente");
                    else{
                        if(vector.length == 1){
                            for(int i=0;i<100;i++){
                                if(agenda.getContactos()[i] == null){
                                    break;
                                }
                                else{
                                    if(agenda.getContactos()[i].getNombre().equals(c.getNombre())){
                                        JOptionPane.showMessageDialog(null,"Contacto a borrar: \n\n"+agenda.getContactos()[i]);
                                        agenda.getContactos()[i] = null;
                                        JOptionPane.showMessageDialog(null,"Contacto borrado exitosamente");
                                    }
                                }
                            }
                        }else{
                            int nContacto=0;
                            vector2 = vector.clone();
                            /*for(int i=0; i<vector2.length; i++){
                                vector2[i].setCorreo(vector2[i].getCorreo()+"    |"+(i+1)+"|");
                                JOptionPane.showMessageDialog(null,agenda.getContactos()[i]);
                            }*/
                            JOptionPane.showMessageDialog(null,"IMPORTANTE, \n\ncada contacto que se mostrará tendrá un número correspondiente \ndesde 1 a n, siendo el primero 1");
                            seguir = 1;
                            while(seguir ==1){
                                while(seguir==1){
                                    resp = JOptionPane.showInputDialog(vector2, vector2[0]);
                                    if(validaEntero(resp)==true)
                                       break;
                                }
                                nContacto = Integer.parseInt(resp);
                                if(nContacto>vector2.length || nContacto<=0){
                                    JOptionPane.showMessageDialog(null,"Numero digitado no corresponde a un contacto, intente de nuevo ");
                                }
                                else{
                                    seguir = 0;
                                }
                            }
                            seguir = 1;
                            for(int i=0;i<1010;i++){
                                if(agenda.getContactos()[i]==vector[nContacto-1]){
                                    JOptionPane.showMessageDialog(null,"Contacto a borrar: \n\t"+agenda.getContactos()[i]);
                                    if(agenda.eliminaContacto(i)==true){
                                        JOptionPane.showMessageDialog(null,"Contacto borrado ");
                                        break;
                                    }
                                }
                            }   
                        }
                    }                     
                    agenda.acomodaLista();
                    break;
                
                case 3:
                     c = new Contacto();
                     seguir = 1;
                     nombre = null;
                     while (seguir==1){
                       nombre = JOptionPane.showInputDialog("Digite el nombre del contacto a buscar: ");
                       if(validaString(nombre)==true)
                           break;
                    }
                     c.setNombre(nombre);
                    tamaño=1;
                    vector = null;
                    vector = agenda.buscarContacto(c);
                    if(vector.length==0)
                         JOptionPane.showMessageDialog(null,"El Contacto no existe en la lista, intente nuevamente");
                    else{
                     JOptionPane.showMessageDialog(null,vector,"Contacto encontrado",0);
                    }
                    break;
                case 4:
                    c = new Contacto();
                    tamaño=1;
                    nombre = null;
                    vector = null;
                   seguir = 1;
                   while (seguir==1){
                       nombre = JOptionPane.showInputDialog("Digite el nombre del contacto a editar: ");
                       if(validaString(nombre)==true)
                           break;
                    }
                    c.setNombre(nombre);
                    vector = agenda.buscarContacto(c);
                    if(vector.length==0)
                         JOptionPane.showMessageDialog(null,"El Contacto no existe en la lista, intente nuevamente");
                    else{
                        String op=null;
                        if(vector.length == 1){
                            for(int i=0;i<100;i++){
                                if(agenda.getContactos()[i] == null){
                                    break;
                                }
                                else{
                                    if(agenda.getContactos()[i].getNombre().equals(c.getNombre())){
                                        c.setNombre(agenda.getContactos()[i].getNombre());
                                        c.setCorreo(agenda.getContactos()[i].getCorreo());
                                        c.setTelefono(agenda.getContactos()[i].getTelefono());
                                        opcion = 0;
                                        seguir = 1;
                                        int band = 0;
                                        JOptionPane.showMessageDialog(null,"Contacto a editar: "+c);
                                        while(seguir==1){
                                            while (seguir==1){
                                                op = JOptionPane.showInputDialog("Campos a modificar: \n\n\t1. Nombre\n\t2. Telefono\n\t3. Correo\n\t4. Salir");
                                                if(validaEntero(op)==true){
                                                    opcion = Integer.parseInt(op);
                                                    if(opcion>0 && opcion<5){
                                                        
                                                        break;
                                                    }else{
                                                        JOptionPane.showMessageDialog(null,"Valor incorrecto, intente nuevamente");
                                                    }
                                                }  
                                            }
                                            switch(opcion){
                                                case 1:
                                                    while (seguir==1){
                                                        nombre = JOptionPane.showInputDialog("Digite el nuevo nombre: ");
                                                         if(validaString(nombre)==true){
                                                             c.setNombre(nombre);
                                                             break;
                                                         }  
                                                     }
                                                    band = 1;
                                                    break;
                                                case 2:
                                                    telefono = null;
                                                    while (seguir==1){
                                                        telefono = JOptionPane.showInputDialog("Digite el nuevo telefono: ");
                                                        if(validaEntero(telefono)==true){
                                                            c.setTelefono(Integer.toUnsignedLong(Integer.parseInt(telefono)));
                                                            break;
                                                        }  
                                                    }                                                   
                                                    band = 1;
                                                    break;
                                                case 3: 
                                                    while (seguir==1){
                                                        correo = JOptionPane.showInputDialog("Digite el nuevo correo: ");
                                                         if(validaString(correo)==true){
                                                             c.setCorreo(correo);
                                                             break;
                                                         }  
                                                     }
                                                    band = 1;
                                                    break;
                                                default:
                                                    break;
                                            }
                                            if(opcion == 4)
                                                break;
                                            while(seguir==1){
                                                 seguir = Integer.parseInt(JOptionPane.showInputDialog("Desea modificar algo mas?: \n\n\t1. Si \n\t2. No")); 
                                                 if( seguir==2){
                                                     break;
                                                 }else{
                                                     if(seguir!=2 && seguir!=1){
                                                         JOptionPane.showMessageDialog(null,"Opcion incorrecta, digite nuevamente");
                                                     }else{
                                                         break;
                                                     }
                                                }
                                            } 
                                        }
                                        if(band ==1){
                                            if(agenda.modificaContacto(c,i)==true){
                                                JOptionPane.showMessageDialog(null,"Contacto modificado");
                                                seguir = 1;
                                                break;
                                            }       
                                        }else{
                                            JOptionPane.showMessageDialog(null,"No se modifico el contacto ");
                                            seguir = 1;
                                            break;
                                        }
                                        
                                    }
                                }
                            }
                        }else{
                            resp = "0";
                            int nContacto=0;
                          
                            /*for(int i=0; i<vector.length; i++){
                                vector2[i].setCorreo(vector2[i].getCorreo()+"    |"+(i+1)+"|");
                            }*/
                            seguir = 1;
                            while(seguir ==1){
                                while(seguir==1){
                                    JOptionPane.showMessageDialog(null,"IMPORTANTE, \n\ncada contacto que se mostrará tendrá un número correspondiente \ndesde 1 a n, siendo el primero 1");
                                    resp = JOptionPane.showInputDialog(vector, vector[0]);
                                    
                                    if(validaEntero(resp)==true)
                                       break;
                                }
                                nContacto = Integer.parseInt(resp);
                                if(nContacto>vector.length || nContacto<=0){
                                    JOptionPane.showMessageDialog(null,"Numero digitado no corresponde a un contacto, intente de nuevo ");
                                }
                                else{
                                    seguir = 0;
                                }
                            }
                            opcion = 0;
                            seguir = 1;
                            int band = 0;
                            for(int i=0;i<100;i++){
                                if(agenda.getContactos()[i] == null){
                                    break;
                                }
                                else{
                                    if((agenda.getContactos()[i].equals(vector[nContacto-1]))){
                                        c.setNombre(agenda.getContactos()[i].getNombre());
                                        c.setCorreo(agenda.getContactos()[i].getCorreo());
                                        c.setTelefono(agenda.getContactos()[i].getTelefono()); 
                                        band = 0;
                                        JOptionPane.showMessageDialog(null,"Contacto a editar: "+c);
                                        while(seguir==1){
                                            while (seguir==1){
                                                op = JOptionPane.showInputDialog("Campos a modificar: \n\n\t1. Nombre\n\t2. Telefono\n\t3. Correo\n\t4. Salir");
                                                if(validaEntero(op)==true){
                                                    opcion = Integer.parseInt(op);
                                                    if(opcion>0 && opcion<5){
                                                        break;
                                                    }else{
                                                        JOptionPane.showMessageDialog(null,"Valor incorrecto, intente nuevamente");
                                                    }
                                                }  
                                            }
                                            
                                           
                                            switch(opcion){
                                                case 1:
                                                    while (seguir==1){
                                                        nombre = JOptionPane.showInputDialog("Digite el nuevo nombre: ");
                                                         if(validaString(nombre)==true){
                                                             c.setNombre(nombre);
                                                             break;
                                                         }  
                                                     }
                                                    band = 1;
                                                    break;
                                                case 2:
                                                    telefono = null;
                                                    while (seguir==1){
                                                        telefono = JOptionPane.showInputDialog("Digite el nuevo telefono: ");
                                                        if(validaEntero(telefono)==true){
                                                            c.setTelefono(Integer.toUnsignedLong(Integer.parseInt(telefono)));
                                                            break;
                                                        }  
                                                    }                                                   
                                                    band = 1;
                                                    break;
                                                case 3: 
                                                    while (seguir==1){
                                                        correo = JOptionPane.showInputDialog("Digite el nuevo correo: ");
                                                         if(validaString(correo)==true){
                                                             c.setCorreo(correo);
                                                             break;
                                                         }  
                                                     }
                                                    band = 1;
                                                    break;
                                                default:
                                                    break;
                                            
                                            }
                                            if(opcion == 4)
                                                break;
                                            while(seguir==1){
                                                 seguir = Integer.parseInt(JOptionPane.showInputDialog("Desea modificar algo mas?: \n\n\t1. Si \n\t2. No")); 
                                                 if( seguir==2){
                                                     break;
                                                 }else{
                                                     if(seguir!=2 && seguir!=1){
                                                         JOptionPane.showMessageDialog(null,"Opcion incorrecta, digite nuevamente");
                                                     }else{
                                                         break;
                                                     }
                                                }
                                            }
                                            
                                        }
                                        if(band==1){
                                            if(agenda.modificaContacto(c,i)==true){
                                                JOptionPane.showMessageDialog(null,"Contacto modificado");
                                                seguir = 1;
                                                break;
                                            }       
                                        }else{
                                            JOptionPane.showMessageDialog(null,"No se modifico el contacto ");
                                            seguir = 1;
                                        }  
                                    }
                                }   
                            }
                        }
                    }  
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,agenda.mostrarContactos(),"Lista de contactos",0);
                    break;
                case 6:
                    Integer res;
                     res = JOptionPane.showConfirmDialog(null, "ESTÁ SEGURO DE SALIR?");
                     if(res==0)
                        seguir = 0;
                     break;
                default:
                    if(opcion!=0)
                        JOptionPane.showMessageDialog(null,"Valor incorrecto, intente nuevamente");
                    
            }    
        }            
    }
        
    /** Metodo que valida el ingreso de un dato entero
     * Valida de que no se digite un tipo de dato diferente a un entero
    */
    public static boolean validaEntero(String valor){
        long conversion;
      
            try{
               conversion = Integer.toUnsignedLong(Integer.parseInt(valor));
            }catch(NumberFormatException l){
                JOptionPane.showMessageDialog(null, "Ingrese un valor correcto");
                return false;
            }
       return true;
    }
    
    /** Metodo que valida el ingreso de un dato String
     * Valida de que no de ingrese espacios
    */
    public static boolean validaString(String valor){
        if("".equals(valor) || valor == null){
                JOptionPane.showMessageDialog(null, "Ingrese un valor correcto");
                //JOptionPane.showMessageDialog(null, );               
                return false;
                
                
            }
            else{             
                int tamaño = valor.length(); 
                if(tamaño==0){                     
                    JOptionPane.showMessageDialog(null, "No hay ningun campo");
                    return false;
                }else{
                    if(tamaño<2){
                        JOptionPane.showMessageDialog(null, "El nombre es muy corto, ingrese al menos 1 silaba");
                        return false;
                    }
                    else{                         
                            return true;
                    }
                }
            }
       
    }
}
    

            
           




