package proweka;

import weka.classifiers.functions.LinearRegression;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;

/**
 *
 * @author Estudiante
 */
public class FastV {
    FastVector fv;
    Instances data;
    int contador = 0;
        
     public FastV(int cantidad) { 
        this.fv = new FastVector();
        this.fv.addElement(new  Attribute("X"));// se indica que el objeto fv va ha tener un atributo "X" numerico
        this.fv.addElement(new Attribute("Y"));  // se indica que el objeto fv va ha tener un atributo "Y" numerico          
        data = new Instances("datos", fv, cantidad); // crea la instancia que va a guardar las instancias que se creen según el valor de "cantidad"
        data.setClassIndex(data.numAttributes() - 1);// se indica que el atributo sobre el cual se va a aplicar la regresion lineal en las instancias es el de la posicion 1 en donde se encuentran los objetos de tipo FastV 
    }
    
    public void addPair(int x, int y) {// en este metodo se agregar la cantidad de puntos o de "x" y "y" segun la cantidad de instancias que se establecieron
        Instance temp;
        temp = new Instance(2); // indica que el numero de atributtos de la instancia es 2
        temp.setValue((Attribute) fv.elementAt(0), x); // se agrega o se cambia en la instancia por el valor de "x"
        temp.setValue((Attribute) fv.elementAt(1), y);
        data.add(temp);// se agrega a la instancia mayor la instancia creada
    }
    
    public double [] getFunction() throws Exception {// Metodo para hallar la regresion
        
        LinearRegression lr = new LinearRegression();
        
        lr.buildClassifier(data);// aplica el algoritmo de regresion lineal
        
        return lr.coefficients(); //devuelve la formula de la regresion con los respectivos coeficientes y valores numericos       
    }
    
}
