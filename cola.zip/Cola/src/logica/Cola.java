/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Luis Andres Agudelo Padilla - 0221520006
 */
public class Cola {
    private Nodo inicio;
    private Nodo fin;
    
    
    public boolean estaVacia(){ //Función que verifica si la cola está vacía.
        return inicio==null; //Returna true si el inicio apunta a null, lo que quiere decir que está vacía la cola.
    }
    
    public boolean insertar(int dato){ // Función para insertar un elemento al final de la cola.
        Nodo nuevo = new Nodo(dato,null); // Se crea el nuevo nodo
        if(estaVacia()){ // Se verifica si la cola esta vacía.
            inicio =fin=nuevo; //En caso de que lo esté se iguala el inicio y fin al nuevo Nodo.
            return true; // Returna true al agregar el nuevo nodo. 
        }else{//Este caso es cuando la cola no está vacía.
            fin.setSiguiente(nuevo); // Al Nodo al que apunta fin le cambia el atrubuto siguiente y lo pone a apuntar al nuevo nodo.
            fin = nuevo; // Se igualz a fin al nuevo nodo, garantizando que que fin sea el ultimo que se ingresó
            return true; // Returna true al agregar el nuevo nodo. 
        }
    }
    
    public boolean eliminar(){ // Función que elimina el primer Nodo de la cola.
        if(estaVacia()) // Se verifica si la cola esta vacía.
            return false; // Returna false en caso de estar vacía ya que no se puede eliminar ningún nodo.
        else{ //En caso de no estar vacía.
            inicio = inicio.getSiguiente(); // EL inicio se pone a apuntar a su atributo siguiente para garantizar que ya la referencia inicio dejó de apuntar al primer nodo.
            return true; // Returna true al eliminar el inicio o primer nodo de la cola.
        }
    }
    
    public void mostrarCola(){ // Función para mostrar la lista (cola).
        Nodo aux = inicio; // Nodo para recorrer la cola desde el inicio.
        System.out.println("");
        while(aux!=null){
            System.out.print("["+aux.getDato()+"]-->"); //Imprime el atributo dato de cada nodo.
            aux=aux.getSiguiente(); //Garantiza que aux recorra la cola.
        }
    }
}
