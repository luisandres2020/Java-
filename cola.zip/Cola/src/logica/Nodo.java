/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author User
 */
public class Nodo {
    private int dato;
    private Nodo siguiente;

    
    
    public Nodo(){
        
    }
    public Nodo(int dato, Nodo nodo){
        this.dato = dato;
        this.siguiente = nodo;
    }
    public Nodo(Nodo nodo){
        this.dato = nodo.dato;
        this.siguiente = nodo.siguiente;
    }

    public int getDato() {
        return dato;
    }

   

    

    public void setDato(int dato) {
        this.dato = dato;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        return "Dato: "+dato+"\nSiguiente: "+siguiente;
    }
    
    
    
    
}
