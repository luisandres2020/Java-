/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;
import logica.*;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class prueba {
     public static void main(String[] args) {
        Cola cola = new Cola();
        int opcion = 0, dato = 0, seguir = 0;
        Exception e=null;
           while(opcion != 4 ){ 
                do{   
                    e=null;
                    try{
                         opcion = Integer.parseInt(JOptionPane.showInputDialog(null,"1. Insertar elemento\n2. Eliminar elemento\n3. Mostar cola"
                                 + "\n4. Salir"));
                     }catch(Exception ex){
                         e = ex;
                         JOptionPane.showMessageDialog(null,"Opcion no valida");
                     }
               }while(e!=null);
                do{
                    e=null;
                    if(opcion == 1){
                        try{
                            dato = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese dato: "));

                        }catch(NumberFormatException ex){
                                e=ex;
                             JOptionPane.showMessageDialog(null,"Dato no valida");
                        }
                    }
                }while(e!=null);
                
                switch(opcion){
                    case 1:
                        if(cola.insertar(dato))
                             JOptionPane.showMessageDialog(null,"Elemento Agregado al final de la cola");
                        break;
                    case 2:
                        if (cola.eliminar())
                            JOptionPane.showMessageDialog(null,"Elemento eliminado al inicio de la cola");
                        break;
                    case 3:
                       cola.mostrarCola();
                       break;
                    case 4:
                        return;
                    default:
                       JOptionPane.showMessageDialog(null,"Opcion Incorrecta"); 
                }
           }   
    } 
}
