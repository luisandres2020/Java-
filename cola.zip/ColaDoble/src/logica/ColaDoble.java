/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author User
 */
public class ColaDoble {
    private Nodo inicio;
    private Nodo fin;
    int tamaño;
    
    
    public boolean estaVacia(){ //Función que verifica si la cola está vacía.
        return inicio==null; //Returna true si inicio apunta a null, lo que quiere decir que está vacía la cola.
    }
    
    public boolean insertarFinal(int dato){ // Función para insertar un elemento al final de la cola.
        Nodo nuevo = new Nodo(dato,null,null); // Se crea el nuevo nodo.
        if(estaVacia()){ // Se verifica si la cola esta vacía.
            inicio =fin=nuevo; //En caso de que lo esté se iguala inicio y fin al nuevo Nodo.
            return true;  // Returna true al agregar el nuevo nodo .
        }else{ // Este caso es cuando la cola no está vacía.
            nuevo.setAnterior(fin); // Se cambia la referencia anterior del nodo nuevo para que apunto a fin.
            fin.setSiguiente(nuevo); // Se cambia la referenia siguiente de fin para que apunte a nuevo.
            fin = nuevo; // Se iguala fin a nuevo para que fin apunte al nuevo nodo ya que este sería el ultimo de la cola.
            return true; // Returna true al agregar el nuevo nodo. 
        }
    }
    
    public boolean insertarInicio(int dato){ // Función para insertar un elemento al inicio de la cola.
        Nodo nuevo = new Nodo(dato,null,null);  // Se crea el nuevo nodo.
        if(estaVacia()){ // Se verifica si la cola esta vacía.
            inicio =fin=nuevo;  //En caso de que lo esté se iguala inicio y fin al nuevo nodo.
            return true; // Returna true al agregar el nuevo nodo. 
        }else{ // Este caso es cuando la cola no está vacía.
           nuevo.setSiguiente(inicio); // Se cambia la referencia siguiente del nodo nuevo para que apunto a inicio.
           inicio.setAnterior(nuevo); // Se cambia la referenia anterior de inicio para que apunte a nuevo.
           inicio = nuevo;  // Se iguala inicio a nuevo para que inicio apunte al nuevo nodo ya que este sería el primero de la cola.
           return true; // Returna true al agregar el nuevo nodo. 
        }
    }
    
    public boolean eliminarInicio(){ // Función para eliminar un elemento al inicio de la cola.
        if(estaVacia()) // Se verifica si la cola esta vacía.
            return false; // Returna false en caso de estar vacía ya que no se puede eliminar ningún nodo.
        else{ //En caso de no estar vacía.
            if(inicio == fin){ // Y si solo hay un nodo
                inicio=fin=null; // inicio y fin como apuntan al mismo nodo se hacen null.
                return true; // Returna true al eliminar el nodo.
            }else{ // Y si no hay un solo nodo.
                inicio = inicio.getSiguiente(); // EL inicio se pone a apuntar a su atributo siguiente para garantizar que ya la referencia inicio dejó de apuntar al primer nodo.
                inicio.getAnterior().setSiguiente(null); // Se devuelve al nodo donde apuntaba inicio anteriormente y se cambia la referencia siguiente de este para que apunte a null
                inicio.setAnterior(null);// Se cambia la referencia anterior de inicio en null y asi deje de apuntar al que anteriormente era el inicio.
                return true; // Returna true al eliminar el inicio o primer nodo de la cola.
            }
        }
    }
    
    public boolean eliminarFinal(){
        if(estaVacia()) // Se verifica si la cola esta vacía.
            return false; // Returna false en caso de estar vacía ya que no se puede eliminar ningún nodo.
        else{//En caso de no estar vacía.
            if(inicio==fin){ // Y si solo hay un nodo.
                inicio=fin=null; // inicio y fin como apuntan al mismo nodo se hacen null.
                return true; // Returna true al eliminar el nodo.
            }else{ // Y si no hay un solo nodo.
                fin = fin.getAnterior();  // El fin se pone a apuntar a su atributo anterior del mismo para garantizar que ya la referencia fin dejo de apuntar al primer nodo.
                fin.getSiguiente().setAnterior(null); // Se devuelve al nodo donde apuntaba fin anteriormente y se cambia la referencia anterior de este para que apunte a null.
                fin.setSiguiente(null); // Se cambia la referencia siguiente de fin en null y así deje de apuntar al que anteriormente era el fin.
                return true; // Returna true al eliminar el fin o último nodo de la cola.
            }
        }
    }
    
    public void mostrarCola(){ // Función para mostrar la lista (cola).
        Nodo aux = inicio; // Nodo para recorrer la cola desde el inicio.
        System.out.println("");
        while(aux!=null){ 
            System.out.print("["+aux.getDato()+"]<-->"); //Imprime el atributo dato de cada nodo.
            aux=aux.getSiguiente(); // Garantiza que aux recorra la cola.
        }
    }
    
    
    
}
