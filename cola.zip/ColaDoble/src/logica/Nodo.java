/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author User
 */
public class Nodo {
    private int dato;
    private Nodo siguiente;
    private Nodo anterior;
    
    
    public Nodo(){
        
    }
    public Nodo(int dato, Nodo siguiente, Nodo anterior){
        this.dato = dato;
        this.siguiente = siguiente;
        this.anterior = anterior;
    }
    public Nodo(Nodo nodo){
        this.dato = nodo.dato;
        this.siguiente = nodo.siguiente;
        this.anterior = nodo.anterior;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public Nodo getAnterior() {
        return anterior;
    }

    public void setAnterior(Nodo anterior) {
        this.anterior = anterior;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public String toString() {
        return "Dato: "+dato+"\nSiguiente: "+siguiente;
    }
    
    
    
    
}
