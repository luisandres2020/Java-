/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Luis Andres Agudelo Padilla - 0221520006
 */
public class ColaCircular { 
    private Nodo inicio;
    private Nodo fin;
   
    
    
    public boolean estaVacia(){  //Función que verifica si la cola está vacía.
        return inicio==null; //Returna true si inicio apunta a null, lo que quiere decir que está vacía.
    }
    
    public boolean insertar(int dato){ // Función para insertar un elemento al final de la cola.
        Nodo nuevo = new Nodo(dato,null); // Se crea el nuevo nodo.
        if(estaVacia()){  // Se verifica si la cola esta vacía.
            inicio =fin=nuevo; //En caso de que lo esté se iguala inicio y fin al nuevo Nodo.
            fin.setSiguiente(inicio); // Fin en su atributo siguiente apunta a inicio para garatizar que la cola sea circular (fin apunta a fin).
            return true; // Returna true al agregar el nuevo nodo. 
        }else{ // Este caso es cuando la cola no está vacía.
            fin.setSiguiente(nuevo); // Al nodo al que apunta fin  se le cambia el atributo siguiente y se pone a apuntar al nuevo nodo.
            fin = nuevo; // Se iguala a fin al nuevo nodo, garantizando que que fin apunte al último nodo que se ingresó.
            fin.setSiguiente(inicio); //Fin en su atributo siguiente apunta a inicio para garatizar que la cola sea circular.
            return true; // Returna true al agregar el nuevo nodo. 
        }
    }
    
    public boolean eliminar(){ // Función que elimina el primer Nodo de la cola.
        if(estaVacia()) // Se verifica si la cola esta vacía.
            return false; // Returna false en caso de estar vacía ya que no se puede eliminar ningún nodo.
        else{//En caso de no estar vacía.
            if(inicio==fin){ // Y si solo hay un nodo.
                inicio=fin=null; // Inicio y fin como apuntan al mismo nodo se hacen null.
                return true; // Returna true al eliminar el nodo.
            }else{ // Y si no hay un solo nodo.
                inicio = inicio.getSiguiente(); // // EL inicio se pone a apuntar a su atributo siguiente para garantizar que ya la referencia inicio dejo de apuntar al primer nodo.
                fin.setSiguiente(inicio); // Fin se pone apuntar a su referencia siguiente a inicio para gantizar que la cola sea circular.
                return true; // Returna true al eliminar el inicio o primer nodo de la cola.
            }
        }
    }
    
    public void mostrarCola(){ // Función para mostrar la lista (cola).
        Nodo aux = inicio; // Nodo para recorrer la cola desde el inicio.
        if(estaVacia()) // Se verifica que no esté vacía .
            return;
        System.out.println("");
        do{
            System.out.print("["+aux.getDato()+"]-->");//Imprime el atributo dato de cada nodo.
            aux=aux.getSiguiente(); // Garantiza que aux recorra la cola.
        }while(aux!=inicio);
        
    }
    
    
    
}
