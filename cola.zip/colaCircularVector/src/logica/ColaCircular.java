/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author User
 */
public class ColaCircular { //Clase para cola circular con vector o array.
    private int inicio; // Indica el inicio de la cola.
    private int tamaño; // Tamaño de la cola, se define desde que se instancia un objeto de este tipo ya que es un vector estático.
    private int nElementos; // Indica el numero de elementos de la cola.
    private int []cola; // Vector cola.
    
    public ColaCircular(int tamaño){ // Método constructor, solo recibe como parámetro el tamaño del vecto cola.
        this.tamaño = tamaño;
        this.inicio = 0;
        this.nElementos = 0;
        this.cola = new int[tamaño];  // Se inicializa el vector cola con el tamaño pasado como parámetro en el método constructor.
    }
    
    public boolean insertar(int dato){ // Método para insertar al final de la cola, recibe como parámetro el dato que se va a agregar en la cola.
        if(nElementos==tamaño){ // Verifica que la cola esté llena.
            return false;// Returna false si la cola está llena ya que no se puede agregar un elemento en caso de estarlo.
        }else{// Si no está llena.
            int posicion = (inicio+nElementos)%tamaño; // Formula para determinar en que posición del vector cola se va a guardar el dato.
            cola[posicion] = dato; // Se agrega el dato en la cola.
            nElementos++; // Se incrementa el número de datos en el vector cola.
            return true; // Returna true al agregar el nuevo dato.
        }
    }
    
    public boolean eliminar(){// Método para eliminar el último dato agregado en el vector cola.
        inicio = (inicio+1)%tamaño; // Formula para determinar a que posición hará referencia inicio y así no mostrar la posición a que inicio hacia referencia anteriormente.
        nElementos--; // Se decrementa el número de elementos en la cola.
        return true; // Returna true al "eliminar" el inicio o primer elemento de la cola.
    }
    
    public void mostrarCola(){ // Función para mostrar la lista (cola).
        if(nElementos==0)//Se verifica que la cola no esté vacia.
            return; // Se sale del método en caso de que lo esté.
        System.out.println("");
        int j=0; // Contador para determianr el número de lementos que se mostraron de la cola.
        for(int i=inicio;i<nElementos+inicio;i++){
            if(i==tamaño)
                break;// En caso de ser el contador i igual al tamaño del vector se rompe el ciclo, esto garantiza que en la siguiente linea no se muestre la posición del vector en i igual o mayor a su tamaño.
            System.out.print("["+cola[i]+"]-->");
            j++; // Su incremento muestra el número de elementos que se han mostrado.
            
        }
         if(nElementos-j!=0){// Se verifica que el número de elementos que se han mostrado sea el número de elementos que estan en el vector.
            for(int i=0;i<nElementos-j; i++){
                System.out.print("["+cola[i]+"]-->");
            } 
        }
        System.out.print("["+cola[inicio]+"]");// Solo es para indicar que como es una cola circular al momento de imprimir en pantalla se fin apunte al inicio.  
    }
}
