/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;
import javax.swing.JTable;
import java.text.SimpleDateFormat;
import java.util.Date;
import vista.prueba;
/**
 *
 * @author User
 */
public class Cola{
    private Nodo inicio;
    private Nodo fin;
    private int tamaño;

    public Nodo getInicio() {
        return inicio;
    }

    public void setInicio(Nodo inicio) {
        this.inicio = inicio;
    }

    public Nodo getFin() {
        return fin;
    }

    public void setFin(Nodo fin) {
        this.fin = fin;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }
    
    
    public boolean estaVacia(){
        return inicio==null;
    }
    
    public boolean insertar(Tarea tarea){
        prueba p = new prueba();
        if(p.validaFecha(tarea.getFecha())){
           //System.out.println("entra valida fecha");
            Nodo nuevo = new Nodo(tarea);
            if(estaVacia()){
                 //System.out.println("entra cuando esta vacia");
                inicio =fin=nuevo;
                tamaño++;
                return true;
            }else{
                long fecha =  p.convertidor(tarea.getFecha());
                long fechaInicio = p.convertidor(inicio.getTarea().getFecha());
                if(fechaInicio >= fecha){
                    nuevo.setSiguiente(inicio);
                    inicio = nuevo;
                    tamaño++;
                    return true;
                }else{
                    long fechaFin = p.convertidor(fin.getTarea().getFecha());
                    if(fechaFin<=fecha){
                        fin.setSiguiente(nuevo);
                        fin = nuevo;
                        tamaño++;
                        return true;
                    }else{
                        long fechaAux;
                        Nodo aux = inicio;
                        while(aux!=null){
                            fechaAux = p.convertidor(aux.getSiguiente().getTarea().getFecha());
                            if(fecha<=fechaAux){
                                nuevo.setSiguiente(aux.getSiguiente());
                                aux.setSiguiente(nuevo);
                                tamaño++;
                                return true;
                            }
                            aux = aux.getSiguiente();
                        }
                    }
                }
            }
        }
        return false;
    }



    
    public Nodo eliminar(){
        if(estaVacia())
            return null;
        else{
            Nodo aux = inicio;
            inicio = inicio.getSiguiente();
            System.out.println(aux.getTarea().getDecripción());
            tamaño--;
            return aux;
        }
    }
    
    /*public Nodo mostrarCola(Nodo nodo){
        if(!estaVacia()){
            if(nodo.getSiguiente()!=null){
                nodo= nodo.getSiguiente();
                return mostrarCola(nodo);
            }
        }
        return null;
    } */
    
    public Nodo mostrarCola(int n){
        Nodo aux = inicio;
        if(!estaVacia()){
            for(int i=0;i<tamaño; i++){
                if(i==n){
                    return aux;
                }
                aux = aux.getSiguiente();
            }
        }
        return null;
    } 
    
    public Nodo buscar(int n){
        if(n>tamaño)
            return null;
        if(n == 1)
            return inicio;
        else{
            if(n==tamaño)
                return fin;
            else{
                Nodo aux = inicio;
                 for(int i=0;i<tamaño;i++){
                     if(i+1==n){
                         return aux;
                     }
                     aux = aux.getSiguiente();
                 }
            }
        }
       return null;
    }
    
    public boolean aplazar(Date fecha,int n){
        Nodo aux = buscar(n);
        if(aux != null){
            aux.getTarea().setFecha(fecha);
            return true;
        }
        return false;
       
    }
    
     public boolean organizarAscendente(){
        prueba p = new prueba();
         if(inicio == fin)
            return false;
        else{
            if(inicio.getSiguiente()==fin){
                Nodo aux = inicio;
                if(p.convertidor(inicio.getTarea().getFecha())>=p.convertidor(fin.getTarea().getFecha())){
                    fin.setSiguiente(inicio);
                    inicio.setSiguiente(null);
                    inicio = fin;
                    fin = aux;
                    return true;
                }
            }else{
                try{
                Nodo aux1,aux2,aux3=inicio,rl=inicio,rr;
                int i=0, j=0;
                while(rl!=null){
                    rr=rl.getSiguiente();
                    aux1 = rl;
                    aux2 = rr.getSiguiente();
                    while(rr!=null){
                        if(p.convertidor(rl.getTarea().getFecha())>=p.convertidor(rr.getTarea().getFecha())){
                            aux1.setSiguiente(aux2);
                            rr.setSiguiente(rl);
                            rl = rr;
                            rr = aux1.getSiguiente();
                            if(rr!=null)
                                aux2 = aux2.getSiguiente();
                            if(i!=0)
                                aux3.setSiguiente(rl);
                            else{if(j==0){
                                    aux1 = aux1.getSiguiente();
                                    rr = rr.getSiguiente();
                                }
                            }
                        }else{aux1 = aux1.getSiguiente();
                            rr = rr.getSiguiente();
                            if(rr!=null){
                                aux2 = aux2.getSiguiente();
                            }
                        }
                        j++;
                    }
                    if(i==0)
                        inicio = rl;
                    aux3 = rl;
                    rl = rl.getSiguiente();
                    i++;}
            }catch(Exception e){
                
            }
                
            }
            }

           
        return true;
    }
    
    
            
            
            /*SimpleDateFormat f = new SimpleDateFormat("hh:mm");
            Nodo aux = inicio; 
            String datos[][] = new String[tamaño][4];
            for(int i=0;i<tamaño;i++){
                datos[i][0] = Integer.toString(i+1);
                datos[i][1] = aux.getTarea().getDecripción();
                datos[i][2] = aux.getTarea().getFecha().getDate()+"/"+aux.getTarea().getFecha().getMonth()+"/"+aux.getTarea().getFecha().getYear();
                datos[i][3] = f.format(aux.getTarea().getFecha());
            }
            JTable tabla = new JTable();
            tabla.setModel(new javax.swing.table.DefaultTableModel(datos,new String [] {"NUMERO", "\tTAREA", "\tFECHA", "\tHORA"}));
            tabla.setVisible(true);  */  
}
    ////}
//
    
   
    

