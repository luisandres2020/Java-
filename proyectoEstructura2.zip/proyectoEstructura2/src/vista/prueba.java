/*************************************************
***********************
* Palabra de honor:
* - No he discutido ni mostrado el código de mi programa con alguien que no sea mi
*compañero, Profesor o con el monitor asignado a este curso.
*
* - No he utilizado código obtenido de otro u otros estudiantes,
* O cualquier otra fuente no autorizada, ya sea modificado o sin modificar.
*
* - Si cualquier código o documentación utilizada en mi programa
* Fue obtenido de otra fuente, tal como un libro de texto o curso
* Notas, debe ser claramente señalado con una cita apropiada en
* Los comentarios de mi programa.
*
* Luis Andres Agudelo Padilla - 0221520006
*
**************************************************
********************* /

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import logica.Cola;
import logica.Nodo;
import logica.Tarea;

/**
 *
 * @author Luis Agudelo
 */
public class prueba {
    private static Vtareas tabla = new Vtareas();
    public static void main(String[] a ){
        Cola tareas = new Cola();
        
        int opcion = 0, dato = 0;
        Exception e=null;
           while(opcion != 5 ){ 
                do{   
                    e=null;
                    try{
                         opcion = Integer.parseInt(JOptionPane.showInputDialog(null,"1. Agregar Tarea\n2. Editar Tarea\n3. Mostar Lista de Tareas"
                                 + "\n4. Hacer Primera tarea \n5. Salir"));
                     }catch(Exception ex){
                         e = ex;
                         JOptionPane.showMessageDialog(null,"Opcion no valida");
                     }
               }while(e!=null);
                switch(opcion){
                    case 1:
                        if(tareas.insertar(leerTarea())){
                             JOptionPane.showMessageDialog(null,"TAREA GUARDADA CORRECTAMENTE");
                             tabla(tareas);
                        }
                        break;
                    case 2:
                       int año,mes, dia,h,m;
                        int numero;
                        if(tareas.estaVacia()){
                            JOptionPane.showMessageDialog(null,"NO HAY TAREAS INGRESADAS AUN",null,JOptionPane.ERROR_MESSAGE);
                            break;
                        }
                        do{
                            numero = validaEntero(JOptionPane.showInputDialog("Digite el numero de la tarea: ")); 
                            if(tareas.getTamaño()<numero)
                                JOptionPane.showMessageDialog(null,"EL NUMERO DE LA TAREA SUPERA LA CANTIDAD DE LAS MISMAS");
                         }while(numero<0 || tareas.getTamaño()<numero);
                        
                        Nodo aux = tareas.buscar(numero);
                        if (aux!=null){
                            JOptionPane.showMessageDialog(null,"TAREA ENCONTRADA\n\n"+aux.getTarea().getDecripción());
                            int op=0;
                            while(op!=4){
                                do{
                                    op = validaEntero(JOptionPane.showInputDialog(null,"1. Editar Hora\n2. Editar Fecha\n3. Editar Fecha y Hora"
                                 + "\n4. Salir"));
                                    
                                }while(op<1 || op>4);
                                if(op==1 || op==2 || op==3)
                                    break;
                            }
                            switch(op){
                                
                                case 1 :
                                    while(true){
                                        h = ingresarHora();
                                        m = ingresarMinuto();
                                        aux.getTarea().getFecha().setHours(h);
                                        aux.getTarea().getFecha().setMinutes(m);
                                        if(validaFecha(aux.getTarea().getFecha()))
                                            break;
                                        else{
                                            JOptionPane.showMessageDialog(null,"DIGITE UNA HORA MAYOR A LA ACTUAL");
                                        }
                                    }
                                    tareas.organizarAscendente();
                                    JOptionPane.showMessageDialog(null,"TAREA EDITADA");
                                     tabla(tareas);
                                    break;
                                case 2:
                                    while(true){
                                        año = ingresarAño();
                                        mes = ingresarMes();
                                        dia = ingresarDia(mes,año);
                                        aux.getTarea().getFecha().setYear(año-1900);
                                        aux.getTarea().getFecha().setMonth(mes-1);
                                        aux.getTarea().getFecha().setDate(dia);
                                        if(validaFecha(aux.getTarea().getFecha()))
                                            break;
                                    }
                                    tareas.organizarAscendente();
                                    JOptionPane.showMessageDialog(null,"TAREA EDITADA");
                                    tabla(tareas);
                                    break;
                                case 3:
                                    
                                    do{
                                        año = ingresarAño();
                                        mes = ingresarMes();
                                        dia = ingresarDia(mes,año);
                                        h = ingresarHora();
                                        m = ingresarMinuto();
                                        aux.getTarea().getFecha().setYear(año-1900);
                                        aux.getTarea().getFecha().setMonth(mes-1);
                                        aux.getTarea().getFecha().setDate(dia);
                                        aux.getTarea().getFecha().setHours(h);
                                        aux.getTarea().getFecha().setMinutes(m);
                                        if(validaFecha(aux.getTarea().getFecha()))
                                            break;
                                    }while(!validaFecha(aux.getTarea().getFecha()));
                                    tareas.organizarAscendente();
                                    JOptionPane.showMessageDialog(null,"TAREA EDITADA");
                                     tabla(tareas);
                                    break;
                                case 4:
                                    break;
                                default:
                                     JOptionPane.showMessageDialog(null,"OPCION INCORRECTA",null,JOptionPane.ERROR_MESSAGE);
                            }
                            
                        }
                            
                        break;
                    case 3:
                        if(tareas.estaVacia()){
                            JOptionPane.showMessageDialog(null,"NO HAY TAREAS INGRESADAS AUN",null,JOptionPane.ERROR_MESSAGE);
                            break;
                        }
                       tabla(tareas);
                       break;
                   case 4:
                       Nodo aux2 = tareas.eliminar();
                       if( aux2!=null){
                            JOptionPane.showMessageDialog(null,"PRIMERA TAREA REALIZADA\n\n"+aux2.getTarea().getDecripción());
                            tabla(tareas);
                       }else{
                           JOptionPane.showMessageDialog(null,"NO HAY TAREAS INGRESADAS AUN",null,JOptionPane.ERROR_MESSAGE);
                       }
                       break;
                    case 5:
                        tabla.dispose();
                        return;
                    default:
                       JOptionPane.showMessageDialog(null,"Opcion Incorrecta"); 
                }
           }   
    }
    
    public static Tarea leerTarea(){
        String tarea;
        int  año,mes,dia,hora,minuto;
        Date fActual = new Date();
        /*SimpleDateFormat a = new SimpleDateFormat("YYYY");
        SimpleDateFormat m = new SimpleDateFormat("MM");
        SimpleDateFormat d = new SimpleDateFormat("dd");
        fActual.setYear(Integer.valueOf(a.format(fActual)));
        fActual.setMonth(Integer.valueOf(m.format(fActual)));
        fActual.setDate(Integer.valueOf(d.format(fActual)));*/
        tarea = JOptionPane.showInputDialog("Digite tarea: ");
        Date fecha = new Date();
        do{
            año = ingresarAño();
            mes = ingresarMes();
            dia = ingresarDia(mes,año);
            hora = ingresarHora();
            minuto = ingresarMinuto();
            fecha.setYear(año-1900);
            fecha.setMonth(mes-1);
            fecha.setDate(dia);
            fecha.setHours(hora);
            fecha.setMinutes(minuto);
        }while(!validaFecha(fecha));
        Tarea t = new Tarea(tarea,fecha);
        return t;
    }
    
    public static int validaEntero(String s){
        int dato;
        try{
            dato = Integer.parseInt(s);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"DATO INCORRECTO");
            return -1;
        }
        return dato;
    }
    
    public static int ingresarDia(int mes, int año){
        Date fActual = new Date();
        Date fe = new Date();
        fe.setMonth(mes-1);
        //System.out.println("mes en  ingresa dia dia ="+fe.getMonth());
        fe.setYear(año-1900);
        int dia;
        do{    
            do{
               dia = validaEntero(JOptionPane.showInputDialog("Digite dia: ")); 
            }while(dia<0); 
            fe.setDate(dia);
            if(!verificaDia(año,mes,dia))
                JOptionPane.showMessageDialog(null,"EL NUMERO DE DIA DIGITADO NO CORRESPONDE AL NUMERO DE DIAS DEL MES");
        }while(!verificaDia(año,mes,dia));
        return dia;
    }
    
    public static int ingresarMes(){
        Date fActual = new Date(); 
        int mes;
        do{
           mes = validaEntero(JOptionPane.showInputDialog("Digite mes: ")); 
           if(12<mes)
               JOptionPane.showMessageDialog(null,"DIGITE UN MES DE 1 A 12");
        }while(mes<0  || 12<mes);
        return mes;
    }
    
    public static int ingresarAño(){
        Date fActual = new Date(); 
        int año;
        do{
           año = validaEntero(JOptionPane.showInputDialog("Digite año: ")); 
           if(0<año && año<fActual.getYear()+1900)
               JOptionPane.showMessageDialog(null,"DIGITE UN AÑO MAYOR O IGUAL AL ACTUAL");
        }while(año<0 || año<fActual.getYear()+1900);
        return año;
    }
    
    public static int ingresarHora(){
        Date fActual = new Date(); 
        int hora;
        do{
           hora = validaEntero(JOptionPane.showInputDialog("Digite hora de 00 a 23: ")); 
           if(hora>23)
               JOptionPane.showMessageDialog(null,"DIGITE LA HORA ENTRE LAS 00(12:00 AM) Y LAS 23 (11:00 PM)");
        }while(hora<0 || hora>23);
        return hora;
    }
    
    public static int ingresarMinuto(){
        Date fActual = new Date(); 
        int minuto;
        do{
           minuto = validaEntero(JOptionPane.showInputDialog("Digite minuto de 00 a 59: ")); 
           if(minuto>59)
               JOptionPane.showMessageDialog(null,"DIGITE EN EL CAMPO MINUTO DE 00 A 59");
        }while(minuto<0 || minuto>59 );
        return minuto;
    }
    
    public static boolean verificaDia(int año,int mes, int dia){
        //System.out.println("mes en  verifica dia ="+mes);
        if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12){
            if(dia<=31)
                return true;
        }
        else{
            if(mes==2){
                if(dia<=29){
                    if(dia==29 && esViciesto(año))
                        return true;
                    else{
                        if(dia<29)
                            return true;
                    }
                }
            }else{
                if(dia<=30)
                    return true;
            }
        }
        //System.out.println("RETUNA FALSE EN VERIFICA");
        return false;                   
    }
       
     
    
    public static boolean esViciesto(int año){
        if((año % 4 == 0)  && (año % 100 != 0) || (año % 400 == 0))
            return true;
        else{
            return false;
        }
    }
    
    public static long  convertidor(Date fecha){
       return (fecha.getYear()+1900)*100000000 +  (fecha.getMonth()+1)*1000000 + fecha.getDate()*10000 + fecha.getHours()*100 + fecha.getMinutes(); 
    }
    
    public static  boolean validaFecha(Date fecha){
        Date fechaActual = new Date();
       // JOptionPane.showMessageDialog(null, "en valida fecha"+fecha.getHours());
        long fechaA = (fechaActual.getYear()+1900)*100000000 +  (fechaActual.getMonth()+1)*1000000 + fechaActual.getDate()*10000 + fechaActual.getHours()*100 + fechaActual.getMinutes();
        long f =  (fecha.getYear()+1900)*100000000 +  (fecha.getMonth()+1)*1000000 + fecha.getDate()*10000 + fecha.getHours()*100 + fecha.getMinutes();
        if(f>fechaA)
            return true;
        JOptionPane.showMessageDialog(null,"LA FECHA INGRESA ES IGUAL O MENOR A LA ACTUAL\nINTENTE NUEVAMENTE",null, JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    public static void tabla(Cola tareas){
        if(!tareas.estaVacia()){    
        tabla.dispose();
            SimpleDateFormat f = new SimpleDateFormat("hh:mm a");
                String datos[][] = new String[tareas.getTamaño()][4];
                for(int i=0;i<tareas.getTamaño();i++){
                    datos[i][0] = Integer.toString(i+1);
                    datos[i][1] = tareas.mostrarCola(i).getTarea().getDecripción();
                    datos[i][2] = tareas.mostrarCola(i).getTarea().getFecha().getDate()+"/"+(tareas.mostrarCola(i).getTarea().getFecha().getMonth()+1)+"/"+(tareas.mostrarCola(i).getTarea().getFecha().getYear()+1900);
                    datos[i][3] = f.format(tareas.mostrarCola(i).getTarea().getFecha());
                }
                 tabla.getTable().setModel(new javax.swing.table.DefaultTableModel(datos,new String [] {"NUMERO", "\tTAREA", "\tFECHA", "\tHORA"}));
                 tabla.setVisible(true);
            
        }else{
            tabla.dispose();
        }
    }
    
    
    
    
    
    
}
