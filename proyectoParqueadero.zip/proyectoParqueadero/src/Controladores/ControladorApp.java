/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.awt.GraphicsConfiguration;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import modelo.Registro;
import modelo.Usuario;
import vista.InicioSesion;

import vista.VentanaApp1;

/**
 *
 * @author Yuli
 */
public class ControladorApp implements ActionListener,KeyListener,java.awt.event.MouseListener {
    private VentanaApp1 ventanaApp;
    private InicioSesion ventanaInicioSesion;
    private Usuario user;

    public ControladorApp(VentanaApp1 ventana, Usuario user)  {
        this.ventanaApp = ventana;
        this.user = user;
        ventana.btnAceptar.addActionListener(this);
        ventana.btnFoto.addActionListener(this);
        ventana.btnBuscar.addActionListener(this);
        ventana.btnFacturar.addActionListener(this);
    }
    
    public ControladorApp(InicioSesion ventana, Usuario user)  {
        this.ventanaInicioSesion = ventana;
        this.user = user;
        ventanaInicioSesion.btnEntrar.addActionListener(this);
        
    }
 
    @Override
    
    public void actionPerformed(ActionEvent ae) {
       System.out.println("entra4");
        if(ventanaApp.isActive()){
            Registro r = null;
            System.out.println("entra3");
            if(ae.getSource().equals(ventanaApp.btnAceptar) && ventanaApp.verificarIngreso()){
                String placa, tipo, observacion;
                int id;
                tipo = ventanaApp.jComboBoxTipo.getSelectedItem().toString();
                System.out.println(tipo);
                placa = ventanaApp.jTextPlaca.getText();
                try{
                    id = Integer.parseInt(ventanaApp.jTextIdCliente.getText());
                }catch(Exception e){
                    id=0;
                }
                    observacion = ventanaApp.jTextObservacion.getText();
                ControladorRegistro registro = getControladorRegistro();
                ventanaApp.validarOperaciones(registro.registrarIngreso(tipo, id, placa, observacion));
            }if(ae.getSource().equals(ventanaApp.btnBuscar) && ventanaApp.verificarBusqueda()){
                System.out.println("entra");
                r = getControladorRegistro().buscarRegistro(ventanaApp.jTextBusqueda.getText());
                if(r!=null){
                    ventanaApp.jTextInformacion.setText(r.toString());
                    if(JOptionPane.showConfirmDialog(null, "Realmente desea salir de Hola Swing?", "Confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)==0 )
                        getControladorRegistro().registrarSalida(r);
                        //getControladorFactura().facturar(r);
                    System.out.println("entra2");
                }
                
            }
        }else if(ventanaInicioSesion.isActive()){
            if(ae.getSource().equals(ventanaInicioSesion.btnEntrar) ){
              // Controlador
            }
        }
    }
    
    
    
    
    public ControladorFactura getControladorFactura(){
        return new ControladorFactura();
    }
    
    
    public ControladorRegistro getControladorRegistro(){
        return new ControladorRegistro();
    }
    
    
    public ControladorRegistro getControladorUsuario(){
        return new ControladorRegistro();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mousePressed(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
