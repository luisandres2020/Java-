/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.io.IOException;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Factura;
import modelo.GenerarDoc;
import modelo.Registro;
import modelo.GenerarDoc;

/**
 *
 * @author Yuli
 */
public class ControladorFactura {   
    
    public Factura facturar(Registro registro){
        Factura factura = new Factura(Calendar.getInstance().getTime(),registro.getFechaHoraIngreso(),registro.getMedioTransporte().getPlaca(),registro.getCliente().getId(),registro.getTarifa());
        GenerarDoc gD = new GenerarDoc();
        
        factura.setHorasServicio(calcularHorasServicio(factura));
        factura.setTotal(calcularCosto(factura));
        factura.guardarFactura(factura);
        try {
            gD.CrearDoc(factura);
        } catch (IOException ex) {
            Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
        return factura;
    }
    
    public long calcularCosto(Factura factura){
        float horas = calcularHorasServicio(factura);
        System.out.println(horas);
        if((horas*3600000)%3600000!=0){
            horas = (int)horas + 1;
        }
           System.out.println(horas);
        return (long) (factura.getTarifa()*horas);
    }
    
    public float calcularHorasServicio(Factura factura){
        System.out.println(factura.getFechaHoraSalida().getTime()+"      " + factura.getFechaHoraIngreso().getTime());
        float horas =  (factura.getFechaHoraSalida().getTime() - factura.getFechaHoraIngreso().getTime());
        return horas/3600000;
    }
    
    public boolean generarFactura(Factura factura) throws IOException{
        new GenerarDoc().CrearDoc(factura);
        return true;
    }
    
}
