/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.util.Calendar;
import java.util.Date;
import modelo.Cliente;
import modelo.MedioTransporte;
import modelo.Registro;

/**
 *
 * @author Yuli
 */
public class ControladorRegistro {
 
    
    public  boolean registrarIngreso(String tipo,  int id,String placa, String observacion ){
        Registro r = new Registro ( observacion, placa,  tipo, id);
        return r.guardar(r);
    }
    
    public boolean registrarSalida(Registro r){
        ControladorFactura controladorFactura = new ControladorFactura ();
        controladorFactura.facturar(r);
        return true;
    }
    
    public Registro buscarRegistro(String info){
        return new Registro().buscarRegistro(info);
    }
    
    
    
    
    
    
}
