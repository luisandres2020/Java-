/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JOptionPane;
import modelo.Cliente;
import modelo.Factura;
import modelo.MedioTransporte;
import modelo.Registro;

/**
 *
 * @author Yuli
 */
public class ConexionBD {
    public static final String URL = "jdbc:mysql://localhost:3306/parqueadero";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    public static PreparedStatement ps;
    public static ResultSet rs;
    String[] añadir_filas = new String[6];
    static boolean delete=false;
    static boolean buscar=false;
    static String ID="";
    public static Connection con;
    
    public ConexionBD(){
       
    }
    
    public static Connection getConection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Conexión Exitosa");

        } catch (Exception e) {
            System.out.println("Error al conectar: " + e);
        }

        return con;
    }//Fin getConection

    public Connection getCon() {
        return con;
    }
    
    
    
    
     /*public  void conectar() {
        Statement st;
        ResultSet rs;
        try {
            st=(Statement) cn.con.createStatement();
            rs=st.executeQuery("select * from cliente");
            while (rs.next()) {                
                System.out.println(rs.getInt("codigo")+" " +rs.getString("nombre")+" " +rs.getString("identificacion"));
            }
            cn.con.close();
        } catch (Exception e) {
        }
        
    }*/
     
    
   public static boolean guardar(Object objeto) {
        try {
            con = getConection();
            switch(objeto.getClass().getSimpleName()){
                case "Factura":
                    Factura f = (Factura)objeto;
                    ps = con.prepareStatement("INSERT INTO facturas(codigo,placa,idCliente,fechaHoraIngreso,fechaHoraSalida,horasServicio,total) VALUES(?,?,?,?,?,?,?)");
                    ps.setInt(1, 0);
                    ps.setString(2,f.getPlaca());
                    ps.setString(3, ""+f.getId());
                    ps.setLong(4,  f.getFechaHoraIngreso().getTime());
                    ps.setLong(5, f.getFechaHoraSalida().getTime());
                    ps.setInt(6, f.getTarifa());
                    ps.setFloat(7, f.getHorasServicio());
                    ps.setLong(8, f.getTotal());
                    break;
                    
                case "Registro":
                    Registro r = (Registro) objeto;
                      try{
                        ps = con.prepareStatement("INSERT INTO clientes(nombre,identificacion,direccion,telefono) VALUES(?,?,?,?)");
                        ps.setString(1,r.getCliente().getNombre());
                        ps.setInt(2,r.getCliente().getId());
                        ps.setString(3,r.getCliente().getDireccion());
                        ps.setString(4,""+r.getCliente().getTelefono());
                        ps.executeUpdate();
                    }catch(Exception e){
                        
                    }
                    try{
                        ps = con.prepareStatement("INSERT INTO mediosTransportes(placa,tipo) VALUES(?,?)");
                        ps.setString(1,r.getMedioTransporte().getPlaca());
                        ps.setString(2,r.getMedioTransporte().getTipo());
                        ps.executeUpdate();
                    }catch(Exception e){
                        
                    }
                    ps = con.prepareStatement("INSERT INTO registros(numero,codigoCliente,codigoMedioTrans,fechaHoraIngreso,tarifa,observacion) VALUES(?,?,?,?,?,?)");
                    ps.setInt(1,0);
                    ps.setString(2,""+r.getCliente().getId());
                    ps.setString(3,r.getMedioTransporte().getPlaca());
                    ps.setLong(4,r.getFechaHoraIngreso().getTime());
                    ps.setInt(5,  r.getTarifa());
                    ps.setString(6, r.getObservacion());
                    System.out.println("hasta aqui 1");
                    break;
                }
                int res = ps.executeUpdate();
                con.close();
                if (res > 0) {
                   return true;
                }
                return false;
                
        }catch (Exception e) {
            System.err.println("Error: " + e.getMessage()); //el err lo que hace es mostrar el mensaje como un error
            return false;
        }
   }
    
     public static Object buscar(String opcion ,String info) {
        try {
            con = getConection();
               MedioTransporte vehiculo = new MedioTransporte();
                Cliente c = new Cliente();
            switch(opcion){
                case "registro":   
                    Registro r = new Registro();
                    String aux;
                    ps = con.prepareStatement("SELECT * FROM MediosTransportes WHERE placa='"+info+"'");
                    rs = ps.executeQuery();
                    if(rs.next()){
                       vehiculo.setPlaca(rs.getString("placa"));
                       vehiculo.setTipo(rs.getString("tipo"));
                       ps = con.prepareStatement("SELECT * FROM Registros WHERE codigoMedioTrans='"+vehiculo.getPlaca()+"'");
                       rs = ps.executeQuery();
                       if(rs.next()){
                         r = new Registro();
                         r.setNumero(rs.getInt("numero"));
                         r.getFechaHoraIngreso().setTime(rs.getLong("fechaHoraIngreso"));
                         r.setMedioTransporte(vehiculo);
                         r.setObservacion(rs.getNString("observacion"));
                         r.setTarifa(rs.getInt("tarifa"));
                       }
                       ps = con.prepareStatement("SELECT * FROM Clientes WHERE identificacion='"+rs.getInt("codigoCliente")+"'");
                       rs = ps.executeQuery();
                       if(rs.next()){
                           c.setNombre(rs.getString("nombre"));
                           c.setId(Integer.parseInt(rs.getString("identificacion")));
                           c.setDireccion(rs.getString("direccion"));
                           c.setTelefono(Integer.parseInt(rs.getString("telefono")));
                           r.setCliente(c);
                       }
                        
                    }else{
                        System.out.println("Registro no encontrado");
                       return null;
                    }
                    return r;
                case "medioTrans":
                    vehiculo = new MedioTransporte ();
                    ps = con.prepareStatement("SELECT * FROM MediosTransportes WHERE placa='"+info+"'");
                    rs = ps.executeQuery();
                    if(rs.next()){
                        vehiculo.setPlaca(rs.getString("placa"));
                        vehiculo.setTipo(rs.getString("tipo"));
                    }else{
                        System.out.println("Registro no encontrado");

                    }
                    return vehiculo;        
                    
                case "Cliente":
                    c = new Cliente ();
                    ps = con.prepareStatement("SELECT * FROM Clientes WHERE identificacion='"+info+"'");
                    rs = ps.executeQuery();
                    if(rs.next()){
                        vehiculo.setPlaca(rs.getString("placa"));
                        vehiculo.setTipo(rs.getString("tipo"));
                    }else{
                        System.out.println("Registro no encontrado");

                    }
                    return c;             
                           
                case "factura":
               //    Array 
                    Long fecha1 = Long.parseLong(info);
                    Long fecha2 = fecha1+86400000;
                    int cantFilas=0;
                    Vector resultado=null ;
                    ps = con.prepareStatement("SELECT * FROM Facturas WHERE fechaHoraSalida<="+fecha2+" AND fechaHoraSalida>="+fecha1);  
                    //ps.setString(1,codigo); 
                    rs = ps.executeQuery();
                    if(rs.next()){    
                        if(rs.last()){//Nos posicionamos al final
                            cantFilas = rs.getRow();//sacamos la cantidad de filas/registros
                            rs.beforeFirst();//nos posicionamos antes del inicio (como viene por defecto)
                        }
                        resultado = new Vector(cantFilas);
                        while(rs.next()){
                           resultado.add(rs);
                        }
                    }
                    else{
                        System.out.println("Producto no encontrado");
                    }
                    return resultado;
            } 
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
        return null;

    }
    
    
 /*   public void eliminar(String nombres){
 
                try {
                    con = getConection();
                    ps = con.prepareStatement("DELETE FROM datos WHERE nombres=?");
                    ps.setString(1,nombres);

                    int res = ps.executeUpdate();
                    if (res > 0) {
                        JOptionPane.showMessageDialog(null,rs.getString("nombres")+" ha sido eliminado/a", "Eliminar Persona", JOptionPane.INFORMATION_MESSAGE);
                       
                    }
                    
                    con.close();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "No se puede eliminar este producto intente de nuevo", "Eliminar producto", JOptionPane.ERROR_MESSAGE);
                    System.err.println("Error: " + e.getMessage()); //el err lo que hace es mostrar el mensaje como un error
                }

    }*/
    
   /* public void modificar(String nombres,String apellidos,int edad,String genero,String pais,String profesion,String id){
        try {
            con = getConection();
            ps = con.prepareStatement("UPDATE datos SET nombres=?,apellidos=?,edad=?,genero=?,pais=?,profesion=? WHERE id=?");
            ps.setString(1,nombres);
            ps.setString(2,apellidos);
            ps.setInt(3, edad);
            ps.setString(4,genero);
            ps.setString(5, pais);
            ps.setString(6, profesion);
            ps.setString(7,id);
           
         

            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Datos modificados exitosamente", "modificar datos", JOptionPane.INFORMATION_MESSAGE);
            }
           
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Fallo al modificar datos", "Guardar datos", JOptionPane.ERROR_MESSAGE);
            System.err.println("Error: " + e.getMessage()); //el err lo que hace es mostrar el mensaje como un error
        }

    
    }*/

    
}
