/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import Persistencia.ConexionBD;
import java.util.Date;

/**
 *
 * @author Yuli
 */
public class Factura {
    private int numero;
    private Date fechaHoraSalida;
    private Date fechaHoraIngreso;
    private String placa;
    private int id;
    private float horasServicio;
    private int tarifa;
    private long total;

    public Factura( Date fechaHoraSalida, Date fechaHoraIngreso, String placa, int id, int tarifa) {
        this.numero = numero;
        this.fechaHoraSalida = fechaHoraSalida;
        this.fechaHoraIngreso = fechaHoraIngreso;
        this.placa = placa;
        this.id = id;
        this.tarifa= tarifa;
    }

    
    public void guardarFactura(Factura factura){
        ConexionBD.guardar(factura);
    }
    
    public void buscarFactura(){
        
    }
   
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Date getFechaHoraSalida() {
        return fechaHoraSalida;
    }

    public void setFechaHoraSalida(Date fechaHoraSalida) {
        this.fechaHoraSalida = fechaHoraSalida;
    }

    public Date getFechaHoraIngreso() {
        return fechaHoraIngreso;
    }

    public void setFechaHoraIngreso(Date fechaHoraIngreso) {
        this.fechaHoraIngreso = fechaHoraIngreso;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getHorasServicio() {
        return horasServicio;
    }

    public void setHorasServicio(float horasServicio) {
        this.horasServicio = horasServicio;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public int getTarifa() {
        return tarifa;
    }

    public void setTarifa(int tarifa) {
        this.tarifa = tarifa;
    }

    
    

    
    
    
}
