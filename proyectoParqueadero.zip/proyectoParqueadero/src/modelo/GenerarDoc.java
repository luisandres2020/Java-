/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package modelo;

import java.io.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.*; 
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class GenerarDoc {
    
    
    public Document CrearDoc(Object objeto) throws IOException {
      //  try {
              Document document = new Document();
            try {
                if(objeto.getClass().getSimpleName().equalsIgnoreCase("Registro")){
                    Registro registro = (Registro) objeto;
                    PdfWriter.getInstance(document, new FileOutputStream("Tickets/ticket_"+registro.getNumero()+".pdf"));
                    return crearTicket(document, registro);
                }else{
                   Factura factura = (Factura) objeto;
                    PdfWriter.getInstance(document, new FileOutputStream("Facturas/ticket_"+factura.getNumero()+".pdf"));
                    return crearFactura(document, factura);
                }
            }catch (FileNotFoundException fileNotFoundException) {
                System.out.println("No se encontró el fichero para generar el pdf, PERO SE CREA" + fileNotFoundException);  
                return null;
            } catch (DocumentException ex) {
            Logger.getLogger(GenerarDoc.class.getName()).log(Level.SEVERE, null, ex);
             System.out.println("elotro" );  
            return null;
        }

    }
    
    public Document crearTicket (Document document, Registro registro) throws IOException, DocumentException{
        SimpleDateFormat formato1 = new SimpleDateFormat("dd/MM/yyyy ");
        SimpleDateFormat formato2 = new SimpleDateFormat("HH:mm:ss");
         Chapter chapter = new Chapter(1);
        String informacion = "Wakandy SAS \n"+
                             "Nit: 123456\n"+
                             "Dirección: Cartagena\n"
                             +"\t Terminal de transporte\n\n"

                              +"Ticket # "+registro.getNumero()+"\n"
                              +"Entrada: "+"\n"
                              +"   Fecha: "+formato1.format(registro.getFechaHoraIngreso())+"\n"
                              +"   Hora: "+formato2.format(registro.getFechaHoraIngreso())+"\n"
                              +"Id: "+registro.getCliente().getId()+"\n"
                              +"Tipo de vehiculo: "+registro.getMedioTransporte().getTipo()+"\n"
                              +"Placa: "+registro.getMedioTransporte().getPlaca()+"\n"
                              +"Observación: "+registro.getObservacion();        
        try{
            document.open();
            Paragraph p = new Paragraph(informacion);
             p.setFont(FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.NORMAL));
            chapter.add(p);
             
        }catch(Exception ex){
            System.out.println("Error al agregar info del ticket");
            return null;
        }
        
        if(registro.getMedioTransporte().getTipo().equalsIgnoreCase("bicicleta"))
            new GeneradorCodigoBarra().crearCodigo(""+registro.getCliente().getId());
        else{
             new GeneradorCodigoBarra().crearCodigo(""+registro.getMedioTransporte().getPlaca());
        }
        Image image;
        try {
            image = Image.getInstance("codebar.png");  
           
             chapter.add(image);
            document.add(chapter);
            document.close();
           
        } catch (BadElementException ex) {
            System.out.println("Image BadElementException" +  ex);
        } catch (IOException ex) {
            System.out.println("Image IOException " +  ex);
        }
        
        return document;
    }
    
    public Document crearFactura(Document document, Factura factura) throws IOException, DocumentException{
        SimpleDateFormat formato1 = new SimpleDateFormat("dd/MM/yyyy ");
        SimpleDateFormat formato2 = new SimpleDateFormat("HH:mm:ss");
        int horas,minutos;
        minutos = (int) ((factura.getHorasServicio()*60)%60);
        horas = (int) ((factura.getHorasServicio()*60)/60);
        Chapter chapter = new Chapter(1);
        
        String informacion = "Wakandy SAS \n"+
                             "Nit: 123456\n"+
                             "Regimen Simplificado\n"+
                             "Dirección: Cartagena\n"
                             +"\t Terminal de transporte\n\n"

                              +"Factura # "+factura.getNumero()+"\n"
                              +"Id: "+factura.getId()+"\n"
                              +"Placa: "+factura.getPlaca()+"\n"
                              
                              +"Entrada: "+"\n"
                              +"   Fecha: "+formato1.format(factura.getFechaHoraIngreso())+"\n"
                              +"   Hora: "+formato2.format(factura.getFechaHoraIngreso())+"\n"
                              +"Salida: "+"\n"
                              +"   Fecha: "+formato1.format(factura.getFechaHoraSalida())+"\n"
                              +"   Hora: "+formato2.format(factura.getFechaHoraSalida())+"\n"
                              +"Tiempo: "+horas+" Horas "+minutos+" Min\n"
                              +" -------------------------- \n\n"
                              +"TOTAL : "+factura.getTotal()+" COP\n";
    
        try{
            document.open();
            Paragraph p = new Paragraph(informacion);
             p.setFont(FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.NORMAL));
            chapter.add(p);
             
        }catch(Exception ex){
            System.out.println("Error al agregar info del ticket");
            return null;
        }
         new GeneradorCodigoBarra().crearCodigo(""+factura.getNumero());
        Image image;
        try {
            image = Image.getInstance("codebar.png");  
            chapter.add(image);
            document.add(chapter);
            document.close();
           
        } catch (BadElementException ex) {
            System.out.println("Image BadElementException" +  ex);
        } catch (IOException ex) {
            System.out.println("Image IOException " +  ex);
        }
       
        return document;
    }
    
}
    
