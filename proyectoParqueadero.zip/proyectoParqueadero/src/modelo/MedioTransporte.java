/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Yuli
 */
public class MedioTransporte {
    private String placa;
    private String tipo;

    public MedioTransporte(String tipo) {
        this.tipo = tipo;
    }

    public MedioTransporte(String placa, String tipo) {
        this.placa = placa;
        this.tipo = tipo;
    }

    public MedioTransporte() {
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Tipo: "+tipo+"\n"
              +"Placa: "+placa;          
    }
    
    
}
