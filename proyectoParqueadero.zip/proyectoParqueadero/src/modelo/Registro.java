/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import Persistencia.ConexionBD;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Candelaria
 */
public class Registro {
    private int numero;
    private Date fechaHoraIngreso;
    private String observacion;
    private MedioTransporte medioTransporte;
    private Cliente cliente;
    private int tarifa;

    /**
    * Constructor por Defecto
    */
    public Registro() {
        fechaHoraIngreso = Calendar.getInstance().getTime();
    }

    public Registro( String observacion, MedioTransporte medioTransporte, Cliente cliente) {
        this.observacion = observacion;
        this.medioTransporte = medioTransporte;
        this.cliente = cliente;
        this.fechaHoraIngreso = Calendar.getInstance().getTime();
        tarifa();;
    }

    public Registro(String observacion, String placa, String tipo,  int id) {
        this.observacion = observacion;
        if(bicicleta(tipo)){
            this.medioTransporte = new MedioTransporte(""+id, tipo);
        }else{
              this.medioTransporte = new MedioTransporte(placa, tipo);
        }
        this.cliente = new Cliente(id);
        this.fechaHoraIngreso = Calendar.getInstance().getTime();
        tarifa();;
    }
    
    public boolean imprimirTicket(){
        return true;
    }
    
    public boolean bicicleta(String tipo){
        if(tipo.equalsIgnoreCase("bicicleta"))
            return true;
        return false;
    }

    @Override
    public String toString() {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String entrada = formato.format(fechaHoraIngreso);
        if(cliente!=null){
            return "Numero: " + numero +"\n"
                   +medioTransporte.toString()+"\n"
                   +"Identificación: "+cliente.getId()+"\n"
                   +"Tarifa: "+tarifa+"\n"
                  +"Entrada: "+entrada +"\n"
                   +"Observacion: "+observacion;
        }else{
            return "Numero: " + numero +"\n"
                   +medioTransporte.toString()+"\n"
                   +"Tarifa: "+tarifa+"\n"
                  +"Entrada: "+entrada +"\n"
                   +"Observacion: "+observacion;
        }
    }
     
    public void tarifa(){
        String tipo = this.medioTransporte.getTipo();
        if(bicicleta(tipo)){
            this.tarifa = 500;
        }else if(tipo.equalsIgnoreCase("moto")){
            this.tarifa = 1000;
        }else{
            this.tarifa = 2500;
        }  
    }
    
    public boolean borrar(){
        return true;
    }
    
    public boolean guardar (Registro r){
        ConexionBD.guardar(r);
        return true;
    }

    public Registro buscarRegistro(String info){
       return (Registro)ConexionBD.buscar("registro", info);
    }
    
    public int getNumero() {
        return numero;
    }

    public void setNumero(int nroTicket) {
        this.numero = nroTicket;
    }

    public int getTarifa() {
        return tarifa;
    }

    public void setTarifa(int tarifa) {
        this.tarifa = tarifa;
    }

   

    public Date getFechaHoraIngreso() {
        return fechaHoraIngreso;
    }

    public void setFechaHoraIngreso(Date fechaHoraIngreso) {
        this.fechaHoraIngreso = fechaHoraIngreso;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public MedioTransporte getMedioTransporte() {
        return medioTransporte;
    }

    public void setMedioTransporte(MedioTransporte medioTransporte) {
        this.medioTransporte = medioTransporte;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
   
}
