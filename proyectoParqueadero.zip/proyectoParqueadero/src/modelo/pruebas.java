/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import Controladores.ControladorApp;
import Controladores.ControladorFactura;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date; 
import vista.InicioSesion;

import vista.VentanaApp1;

/**
 *
 * @author Yuli
*/
public class pruebas {
    public static void main(String a[]) throws IOException{
        /* Registro r = new Registro(1,1,"",new MedioTransporte("bici"),new Cliente());
        GenerarDoc crear = new GenerarDoc();
        crear.CrearDoc(r);*/
        /*  Date fechaE= Calendar.getInstance().getTime();
        Date fechaS = Calendar.getInstance().getTime();
        fechaS.setTime(fechaE.getTime()+5800000);
        MedioTransporte medio = new MedioTransporte("zod45e","moto");
        Cliente cl = new Cliente (11433987);
        Registro r = new Registro (1,"",medio,cl);
        r.setFechaHoraIngreso(fechaE);
        r.setFechaHoraSalida(fechaS);
        ControladorFactura c = new ControladorFactura();
        Factura f = c.facturar(r);*/ 
        // System.out.println(f.getHorasServicio()+" "+f.getTotal());
        // c.generarFactura(f);
        

        VentanaApp1 ventana = new VentanaApp1();
       Usuario u = new Usuario("Luis123","luis2020");
        ControladorApp c = new ControladorApp (ventana,u);
        ventana.setVisible(true);
           
           
        /* ventana.setVisible(true);
        VentanaApp v = new VentanaApp();
        v.setVisible(true);
*/
    }
    
   
    
    
    
}
